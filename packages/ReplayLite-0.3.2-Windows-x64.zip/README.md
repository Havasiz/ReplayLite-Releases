# ReplayLite for Windows

Experimental Windows 11 x64 instant replay and recording using NVIDIA NVENC.

Downloads: https://github.com/Havasiz/ReplayLite-Releases/releases

Run Setup-x64.exe for a per-user installation, or extract the entire Windows-x64.zip
and run ReplayLite.exe. No administrator rights, Visual Studio or FFmpeg needed.
An NVIDIA GPU with NVENC API 12.1-compatible drivers and an NVIDIA-connected
primary SDR landscape display are required. Primarily tested on RTX 4070 Ti.

## Controls

- Ctrl + Alt + Z: overlay
- Alt + F10: save replay
- Alt + F9: start/stop manual recording
- Ctrl + Alt + Shift + M: microphone toggle

Shortcuts are editable. ReplayLite remains in the system tray when the overlay is
closed; exit through its tray menu. System audio starts enabled; microphone and
Windows startup are opt-in. Choose your recordings folder in Settings.

## Updates and data

Settings → General contains Check for updates, Automatic update checks (off by
default), and View releases / Download update. Optional checks run at launch and
once every 24 hours while the app is running. They fetch a small public version
file from GitHub over HTTPS. No GitHub account or token is required; no recordings,
settings or account credentials are uploaded. GitHub receives a normal web request.

Close ReplayLite before running a newer installer. Downloads and installation
always require your choice; automatic checks never silently install software.
The downloads are unsigned and Windows may show an unknown-publisher warning.

Settings/logs live in %LOCALAPPDATA%\ReplayLite and are shared by installed and ZIP
builds. Uninstall preserves this data and recordings. A custom category-rules.ini
in that folder overrides the bundled defaults. To migrate a source-checkout
installation, close it, back up settings, and manually copy its ReplayLite.ini and
custom category rules to that folder. Disable startup in the old copy before
enabling it in the new copy.

## Limitations

Recording has measurable game-performance overhead. HDR, rotated displays and
other GPU vendors are unsupported. Audio enhancements can add source latency;
A/V alignment is not guaranteed to be sample-perfect. Separate system/microphone
tracks must be selected or mixed by your player/editor.

The application source is private. The public distribution repository contains
downloads, documentation and release metadata only. NVIDIA's NVENC header and
its original license notice are included under third_party/.
