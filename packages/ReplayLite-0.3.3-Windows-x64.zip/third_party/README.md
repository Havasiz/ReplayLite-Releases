# NVENC headers

`nvEncodeAPI.h` is NVIDIA's API header as distributed by nv-codec-headers,
tag `n12.1.14.0` (NVIDIA copyright and MIT license are in the header).

Source: https://github.com/FFmpeg/nv-codec-headers/blob/n12.1.14.0/include/ffnvcodec/nvEncodeAPI.h

No driver DLL is redistributed. No FFmpeg encoding/library code is linked.
This stable SDK baseline supports the installed driver's queried API 13.1.
Runtime cannot safely emulate an older struct layout merely by rewriting a version
number; older-than-12.1 drivers require a matching header build, never a forced update.
