# ReplayLite for Windows

Windows 11 x64 instant replay and recording using NVIDIA NVENC.
Downloads: https://github.com/Havasiz/ReplayLite-Releases/releases

Run Setup-x64.exe, or extract the whole Windows-x64.zip and run ReplayLite.exe.
An NVIDIA GPU with NVENC API 12.1-compatible drivers and an NVIDIA-connected
primary SDR landscape monitor are required. No Visual Studio or FFmpeg needed.

## Controls

- Ctrl + Alt + Z: overlay
- Alt + F10: save replay
- Alt + F9: start/stop recording
- Ctrl + Alt + Shift + M: microphone toggle

Shortcuts are editable. The app stays in the tray when the overlay closes.
System audio starts on; microphone and Windows startup are opt-in.

## Updates

ReplayLite checks for updates when it starts and every 24 hours while running.
With Install updates automatically off, a newer version produces a notice and a
link to the download page. Turn it on in Settings > General to install normal
updates quietly at the next app launch, before recording starts.

The publisher can mark an update as an emergency security update. Those updates
may install at app launch even when normal automatic installation is off. Only
instructions signed by the publisher and matching verified installers are accepted.
No installer is started while this copy is recording. Offline or failed checks
cannot receive an emergency instruction. Older app versions without this updater
need a manual update first. Download/signature failures leave the existing files
untouched. If a required installation fails, the updater reports the error.

Checks use public GitHub files over HTTPS. No account token, recordings or settings
are uploaded. GitHub receives an ordinary web request. The signing key stays with
the publisher. The downloads are unsigned by Windows Authenticode, so Windows may
show an unknown-publisher warning; the updater does not bypass security prompts.

## Data

Settings and logs live in %LOCALAPPDATA%\ReplayLite, shared by installed and ZIP
builds. Updates and uninstall preserve settings and recordings. Auto-updating a ZIP
copy adds the normal uninstaller to that folder. Custom category-rules.ini files
in the data folder override bundled defaults. Source-checkout settings can be
copied there manually after backing them up and closing the old app.

Quitting clears the unsaved replay buffer in RAM. Completed recordings remain on
disk. Exit through the tray menu. Choose a recording folder in Settings.

## Limits

Recording has measurable performance cost. HDR, rotated displays and non-NVIDIA
GPUs are unsupported. A/V timing is not guaranteed sample-perfect. Separate audio
tracks need an editor/player that selects or mixes them. Source code stays private;
this package contains the compiled app and NVIDIA's original header/license notice.
