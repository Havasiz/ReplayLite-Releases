# ReplayLite for Windows

Windows 11 x64 instant replay and recording using NVIDIA NVENC.
Downloads: https://github.com/Havasiz/ReplayLite-Releases/releases

Run Setup-x64.exe, or extract the whole Windows-x64.zip and run ReplayLite.exe.
An NVIDIA GPU with NVENC API 12.1-compatible drivers and an NVIDIA-connected
primary SDR landscape monitor are required. No Visual Studio or FFmpeg needed.

## Controls

- Ctrl + Alt + Z: overlay
- Alt + F10: save replay
- Alt + F9: start/stop recording
- Ctrl + Alt + Shift + M: microphone toggle

Shortcuts are editable. The app stays in the tray when the overlay closes.
System audio starts on; microphone and Windows startup are opt-in.
The status icons stay at the physical bottom-right edge when switching apps,
including when replay is off. The overlay leaves the taskbar uncovered.

## Separate audio in Clipchamp

Enable Settings > Audio > Save game + mic files. Each saved replay or manual
recording gets two audio files right beside its MP4: " - Game.m4a" and
" - Mic.m4a". Import all three into Clipchamp, put both audio items at 0:00,
and mute the MP4's attached sound. You can then adjust microphone volume alone.
For an older ReplayLite separate-track clip, use Export clip audio... in Audio
settings. Combined-only recordings cannot be separated after capture.
M4A files keep the original AAC audio without re-encoding. This uses extra disk
space only when enabled (about 6 MB of audio per 150-second clip) and adds no
continuous audio encoder. Existing clips and audio exports are not overwritten.

## Updates

ReplayLite checks for updates when it starts and every 24 hours while running.
With Install updates automatically off, a newer version produces a notice and a
link to the download page. Turn it on in Settings > General to install normal
updates quietly at the next app launch, before recording starts.

The publisher can mark an update as an emergency security update. Those updates
may install at app launch even when normal automatic installation is off. Only
instructions signed by the publisher and matching verified installers are accepted.
No installer is started while this copy is recording. Offline or failed checks
cannot receive an emergency instruction. Older app versions without this updater
need a manual update first. Download/signature failures leave the existing files
untouched. If a required installation fails, the updater reports the error.

Checks use public GitHub files over HTTPS. No account token, recordings or settings
are uploaded. GitHub receives an ordinary web request. The signing key stays with
the publisher. The downloads are unsigned by Windows Authenticode, so Windows may
show an unknown-publisher warning; the updater does not bypass security prompts.

## Data

Settings and logs live in %LOCALAPPDATA%\ReplayLite, shared by installed and ZIP
builds. Updates and uninstall preserve settings and recordings. Auto-updating a ZIP
copy adds the normal uninstaller to that folder. Custom category-rules.ini files
in the data folder override bundled defaults. Source-checkout settings can be
copied there manually after backing them up and closing the old app.

Quitting clears the unsaved replay buffer in RAM. Completed recordings remain on
disk. Exit through the tray menu. Choose a recording folder in Settings.

## Limits

Recording has measurable performance cost. HDR, rotated displays and non-NVIDIA
GPUs are unsupported. A/V timing is not guaranteed sample-perfect. Mixed + Separate audio saves a combined
playback track plus isolated system and microphone tracks in the same MP4. Editors
must support multiple embedded audio tracks to adjust the isolated sources. Source code stays private;
this package contains the compiled app and NVIDIA's original header/license notice.
